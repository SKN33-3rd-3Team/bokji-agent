"""gov24_merged.json을 RAG 설계팀과 합의된 Document 스키마(JSONL)로 변환한다.

rag_design.contracts.Document/Section 규격(schema_version 1.0)에 맞춰
직접 dict를 만든다 (아직 병합 전인 feat/1-rag-design 브랜치 코드를 의존성으로
끌어오지 않기 위해, 검증 규칙만 그대로 재구현했다). 따라서 실제 `Document`
dataclass로의 변환·검증(`rag_design.validation.validate_collection_handoff`는
dict가 아니라 Document 인스턴스를 요구한다)은 두 브랜치가 합쳐진 뒤 별도로
수행해야 한다 — 이 스크립트가 만드는 JSONL은 아직 그 검증을 통과시켜본 적이
없다.

출력:
    data/processed/subsidy_documents.jsonl        전체 (재생성 가능, git 미포함)
    data/processed/subsidy_manifest.json           매니페스트 (재생성 가능, git 미포함)
    data/processed/subsidy_parse_warnings.json     전체 경고 로그 (재생성 가능, git 미포함)
    data/samples/subsidy_documents_sample.jsonl    샘플 5건 (git 포함, 형식 확인용)

사용법:
    python -m rag_chatbot.collectors.gov_24.to_document
"""

import hashlib
import json
import os
import unicodedata
from collections import defaultdict
from datetime import datetime
from enum import Enum
from pathlib import Path

from urllib.parse import parse_qsl, unquote, urlencode, urlsplit, urlunsplit
import re

from dotenv import load_dotenv
from rag_design.citation import sanitize_public_url
from rag_design.url_safety import SECRET_QUERY_NAMES

from .region_utils import extract_region, load_sigungu_code_table

load_dotenv()

# main_gov24.py를 어느 위치(gov_24/ 안, 리포지토리 루트 등)에서 실행하든
# 항상 같은 data/ 폴더에 저장/조회하도록, 이 파일 위치를 기준으로 프로젝트
# 루트를 고정 경로로 잡는다(현재 작업 디렉터리(cwd)에 의존하지 않음).
PROJECT_ROOT = Path(__file__).resolve().parents[4]
MERGED_PATH = str(PROJECT_ROOT / "data" / "raw" / "gov24_merged.json")
DETAIL_FAILED_PATH = str(PROJECT_ROOT / "data" / "raw" / "gov24_service_detail_failed_ids.json")
CONDITIONS_FAILED_PATH = str(PROJECT_ROOT / "data" / "raw" / "gov24_support_conditions_failed_ids.json")
OUT_JSONL = str(PROJECT_ROOT / "data" / "processed" / "subsidy_documents.jsonl")
OUT_MANIFEST = str(PROJECT_ROOT / "data" / "processed" / "subsidy_manifest.json")
OUT_PARSE_WARNINGS = str(PROJECT_ROOT / "data" / "processed" / "subsidy_parse_warnings.json")
SAMPLE_OUT = str(PROJECT_ROOT / "data" / "samples" / "subsidy_documents_sample.jsonl")
SAMPLE_SIZE = 5

# data.go.kr "전국 법정동코드 전체자료" CSV 경로(선택). 지정하면 시군구 5자리
# 코드까지 채워지고, 없으면 시도 코드까지만 채워진다(부정확한 코드를
# 하드코딩하지 않기 위한 설계 — region_utils.py 참고).
SIGUNGU_CODE_CSV = os.getenv("SIGUNGU_CODE_CSV")
GOV24_SERVICE_KEY = os.getenv("GOV24_SERVICE_KEY", "")

SOURCE_DATASET_URL = "https://www.data.go.kr/data/15113968/openapi.do"
LICENSE = "공공데이터포털 이용조건 확인"

# (JSON 필드명, 섹션 제목, section_type 태그) — 전부 serviceDetail 응답 소속.

SECTION_FIELDS = [
    ("서비스목적", "목적", "purpose"),
    ("서비스목적요약", "목적 요약", "purpose_summary"),
    ("지원대상", "지원대상", "support_target"),
    ("선정기준", "선정기준", "eligibility_criteria"),
    ("지원내용", "지원내용", "support_details"),
    ("신청방법", "신청방법", "application_method"),
    ("신청기한", "신청기한", "application_period"),
    ("구비서류", "구비서류", "required_documents"),
    ("본인확인필요구비서류", "본인확인 필요 구비서류", "required_documents_self"),
    ("공무원확인구비서류", "공무원 확인 구비서류", "required_documents_official"),
]

LEGAL_BASIS_FIELDS = ("법령", "행정규칙", "자치법규")

# 문의·접수 창구. 개별 필드는 짧아서 섹션으로 따로 두면 청크만 늘어나므로
# 하나의 섹션으로 합친다("어디에 문의하나요" 질문에 답할 수 있게 임베딩 대상).
CONTACT_FIELDS = [
    ("문의처", "문의처"),
    ("전화문의", "전화문의"),
    ("접수기관명", "접수기관"),
    ("접수기관", "접수기관"),
    ("부서명", "담당부서"),
]

# 분류값·URL·집계값 — 임베딩하지 않고 metadata로만 보존한다.
PASSTHROUGH_METADATA_FIELDS = [
    ("지원유형", "support_type"),
    ("사용자구분", "user_type"),
    ("소관기관유형", "organization_type"),
    ("소관기관코드", "organization_code"),
    ("온라인신청사이트URL", "online_application_url"),
    ("등록일시", "registered_at"),
    ("수정일시", "updated_at_raw"),
    ("조회수", "view_count"),
]


class FieldStatus(str, Enum):
    """필드 하나(또는 근거법령처럼 여러 필드를 묶은 그룹)의 상태.

    - PRESENT: 값이 있음 (근거법령 그룹은 법령/행정규칙/자치법규 중 1개만
      있어도 PRESENT로 본다 — 셋 다 있어야 하는 게 정상이 아니기 때문).
    - MISSING_SOURCE: 조회는 성공했는데 원천 자체에 값이 없는 "진짜 결측".
    - FETCH_FAILED: serviceDetail/supportConditions API 호출 자체가 실패해서
      값이 있었는지 없었는지 알 수 없는 경우. MISSING_SOURCE와 반드시
      구분한다 — 재수집하면 채워질 수 있는 값이기 때문이다.
    """

    PRESENT = "present"
    MISSING_SOURCE = "missing_source"
    FETCH_FAILED = "fetch_failed"


def _canonical_public_source_url(url: object) -> str | None:
    """공통 URL 정책을 통과한 공개 canonical URL만 반환한다."""
    if not isinstance(url, str):
        return None
    try:
        return sanitize_public_url(url, secret_values=(GOV24_SERVICE_KEY,))
    except (TypeError, ValueError):
        return None


def _compute_content_hash(content: str) -> str:
    canonical = unicodedata.normalize("NFC", content).replace("\r\n", "\n").replace("\r", "\n")
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


def _normalize_updated_at(value: str | None) -> str | None:
    """보조금24 응답의 '수정일시'는 레코드마다 형식이 다르다.

    - "YYYY-MM-DD" 형태는 그대로 둔다.
    - "YYYYMMDDHHMMSS"(14자리 숫자) 형태는 ISO 8601로 바꾼다.
    - 둘 다 아니면 None(형식 불명)으로 처리한다.
    """
    if not value:
        return None
    value = value.strip()
    if len(value) == 14 and value.isdigit():
        try:
            # 시:분:초가 있는 값은 타임존이 꼭 있어야 한다 — 공공데이터포털 기준 KST(+09:00)로 명시
            return datetime.strptime(value, "%Y%m%d%H%M%S").isoformat() + "+09:00"
        except ValueError:
            return None
    try:
        datetime.fromisoformat(value)
        return value
    except ValueError:
        return None


_EMBEDDED_URL_PATTERN = re.compile(r"https?://[^\s)\]}>,;\"']+")

_AGE_RANGE_PATTERN = re.compile(
    r"(?:만\s*)?(\d{1,3})\s*(?:세\s*)?"
    r"(?:~|～|∼|〜|[-–—]|부터)\s*"
    r"(?:만\s*)?(\d{1,3})\s*세(?:까지)?"
)
_AGE_LOWER_PATTERN = re.compile(r"(?:만\s*)?(\d{1,3})\s*세\s*(이상|초과)")
_AGE_UPPER_PATTERN = re.compile(r"(?:만\s*)?(\d{1,3})\s*세\s*(이하|미만)")
_DEPENDENT_AGE_CONTEXT_PATTERN = re.compile(
    r"(?:자녀|아동|영유아).{0,20}(?:둔|있는|양육|부양|보호하는)|"
    r"(?:자녀|아동|영유아).{0,20}(?:부모|보호자|가구|아버지|어머니)|"
    r"(?:부모|보호자|가구|아버지|어머니).{0,20}(?:자녀|아동|영유아)"
)
_JA_FIELD_PATTERN = re.compile(r"JA\d{4}")
_MAX_PLAUSIBLE_AGE = 120


def _strip_secret_query_params(url: str) -> str:
    """본문 속에 인용된(citation이 아닌) URL에서 시크릿성 쿼리파라미터 이름만 제거한다.

    지원내용/신청방법 등 원문에 포함된 외부 링크(예: 지자체 게시판)는 우리가
    통제하지 않는 임의의 도메인이라 sanitize_public_url(공식 도메인 전용)을
    쓸 수 없다. 그런데 "key=258"처럼 실제로는 게시글 번호일 뿐인데 파라미터
    이름이 SECRET_QUERY_NAMES와 우연히 겹치는 경우가 있어서, vector_store의
    보안 검증(contains_credential_material)에 오탐으로 걸린다. 값이 아니라
    "이름"만 보고 걸러내는 것이므로, 여기서도 이름만 보고 해당 파라미터만
    제거하고(bbsNo/nttNo 같은 나머지 파라미터는 그대로 둔다) 실제 진짜
    시크릿 값 자체를 판단하려 하지 않는다.
    """
    parts = urlsplit(url)
    if not parts.query:
        return url
    kept = [
        (name, value)
        for name, value in parse_qsl(parts.query, keep_blank_values=True)
        if unquote(name).casefold() not in SECRET_QUERY_NAMES
    ]
    return urlunsplit(
        (parts.scheme, parts.netloc, parts.path, urlencode(kept, doseq=True), parts.fragment)
    )


def _sanitize_embedded_urls(text: str) -> str:
    """본문에 박혀 있는 모든 URL에 대해 시크릿성 쿼리파라미터 이름만 제거한다."""
    return _EMBEDDED_URL_PATTERN.sub(lambda m: _strip_secret_query_params(m.group(0)), text)


def _clean_text(text: str) -> str:
    """공백/개행 정규화 + 본문 속 URL의 시크릿성 쿼리파라미터 제거."""
    lines = [line.strip() for line in text.replace("\r\n", "\n").split("\n")]
    lines = [line for line in lines if line]
    cleaned = "\n".join(lines)
    return _sanitize_embedded_urls(cleaned)


def _coerce_age(value: object) -> int | None:
    """정부24 JA 연령값을 bool 제외 정수로 정규화한다."""

    if isinstance(value, bool):
        return None
    if isinstance(value, int):
        age = value
    elif isinstance(value, str) and value.strip().isdigit():
        age = int(value.strip())
    else:
        return None
    return age if 0 <= age <= _MAX_PLAUSIBLE_AGE else None


def _has_active_support_condition(item: dict) -> bool:
    """연령 외 JA 플래그도 지원조건 수집 성공으로 인식한다."""

    return any(
        _JA_FIELD_PATTERN.fullmatch(key)
        and (
            _coerce_age(value) is not None
            if key in {"JA0110", "JA0111"}
            else value == "Y"
        )
        for key, value in item.items()
        if isinstance(key, str)
    )


def _extract_text_age_bounds(item: dict) -> tuple[int | None, int | None] | None:
    """지원대상/선정기준의 명시적인 ``N세`` 조건만 보수적으로 추출한다.

    서로 다른 연령대가 여러 개 발견되면 단일 범위로 억지 병합하지 않는다.
    출생연도, 학년, '청년/노인' 같은 해석이 필요한 표현도 다루지 않는다.
    """

    text = "\n".join(
        str(item.get(field) or "") for field in ("지원대상", "선정기준")
    )
    segments = [
        part.strip()
        for part in re.split(r"[\n;]|(?:\s*[○●▪■□▶※]\s*)", text)
        if part.strip()
    ]
    candidates: set[tuple[int | None, int | None]] = set()

    for segment in segments:
        # "18세 미만 자녀가 있는 부모"의 18세는 신청자 나이가 아니다.
        # 현재 메타데이터는 연령 주체까지 표현하지 못하므로 이런 관계형
        # 조건은 잘못된 하드 필터보다 미추출을 택한다.
        if _DEPENDENT_AGE_CONTEXT_PATTERN.search(segment):
            continue
        consumed: list[tuple[int, int]] = []
        for match in _AGE_RANGE_PATTERN.finditer(segment):
            start, end = int(match.group(1)), int(match.group(2))
            if 0 <= start <= end <= _MAX_PLAUSIBLE_AGE:
                candidates.add((start, end))
                consumed.append(match.span())

        remainder = "".join(
            char
            for index, char in enumerate(segment)
            if not any(start <= index < end for start, end in consumed)
        )
        lowers = []
        uppers = []
        for match in _AGE_LOWER_PATTERN.finditer(remainder):
            value = int(match.group(1)) + (1 if match.group(2) == "초과" else 0)
            if 0 <= value <= _MAX_PLAUSIBLE_AGE:
                lowers.append(value)
        for match in _AGE_UPPER_PATTERN.finditer(remainder):
            value = int(match.group(1)) - (1 if match.group(2) == "미만" else 0)
            if 0 <= value <= _MAX_PLAUSIBLE_AGE:
                uppers.append(value)
        if lowers or uppers:
            start = max(lowers) if lowers else None
            end = min(uppers) if uppers else None
            if start is None or end is None or start <= end:
                candidates.add((start, end))

    return next(iter(candidates)) if len(candidates) == 1 else None


def extract_age_metadata(item: dict) -> tuple[int | None, int | None, str | None]:
    """JA 조건을 우선하고, 없을 때만 명시적 본문 표현을 사용한다."""

    api_start = _coerce_age(item.get("JA0110"))
    api_end = _coerce_age(item.get("JA0111"))
    if api_start is not None or api_end is not None:
        if api_start is not None and api_end is not None and api_start > api_end:
            return None, None, None
        return api_start, api_end, "support_conditions_api"

    extracted = _extract_text_age_bounds(item)
    if extracted is None:
        return None, None, None
    return extracted[0], extracted[1], "support_target_text"


# 값이 있긴 한데 아무 정보도 없는 표기. 정부24 원천에서 실제로 쓰인 것만 모았다.
# 이걸 걸러내지 않으면 "해당없음"만 담긴 청크가 수만 개 색인된다 — 실측으로
# 본인확인구비서류의 96.8%, 공무원확인구비서류의 93.3%가 이 값이다. 검색
# 결과에 뜨면 사용자에게 아무 도움이 안 되면서 임베딩 비용만 늘린다.
_PLACEHOLDER_VALUES = frozenset(
    {
        "해당없음", "해당 없음", "해당사항없음", "해당사항 없음",
        "없음", "없슴", "무", "-", "N/A", "n/a", ".", "0",
    }
)


def _is_placeholder(text: str) -> bool:
    return text.strip().replace(" ", "") in {
        value.replace(" ", "") for value in _PLACEHOLDER_VALUES
    }


def collect_support_conditions(item: dict) -> tuple[dict, list[str]]:
    """지원조건조회(supportConditions) 응답의 **JA 코드 전체**를 거둔다.

    예전에는 JA0110/JA0111(연령)만 뽑아 쓰고 나머지 46개는 문서에 남기지
    않았다. 그 값들은 별도 사이드카 파일로만 존재해서, 문서를 JSONL로 받아
    쓰는 쪽(평가·분석·재색인)에서는 조건을 전혀 볼 수 없었다.

    두 가지 형태로 저장한다.

    - ``support_conditions``: 받은 그대로의 전체 딕셔너리. 값이 비어 있는
      코드까지 포함해 원본을 손실 없이 보존한다(무엇이 "없음"인지도 정보다).
    - ``support_condition_codes``: 실제로 켜진(Y) 코드만 정렬한 목록. chunk
      metadata로 넘겨 검색 시점에 쓸 수 있게 하려는 값이다. 전체 딕셔너리를
      청크마다 싣지 않는 이유는 크기다 - 청크 8.9만 개에 48개 키를 다 넣으면
      색인이 수십 MB 불어나는데, 실제로 쓸모 있는 건 켜진 코드뿐이다.

    JA 코드의 한글 의미는 공식 코드표가 저장소에 없어서 만들지 않는다.
    임의로 라벨을 지어내면 틀린 조건을 사용자에게 보여주게 된다
    (일부 코드의 의미만 graph/policy_conditions.py 가 알고 있다).
    """

    conditions = {
        key: value for key, value in item.items() if _JA_FIELD_PATTERN.fullmatch(key)
    }
    active = sorted(
        key
        for key, value in conditions.items()
        if isinstance(value, str) and value.strip().upper() == "Y"
    )
    return conditions, active


def _passthrough_value(value: object) -> object | None:
    """metadata로 그대로 보존하는 값. 문자열은 시크릿 제거를 한 번 거친다.

    URL 필드에 API 키가 쿼리파라미터로 붙어 오는 경우가 실제로 있어서,
    본문과 같은 정화 규칙(_sanitize_embedded_urls)을 적용한다.
    """

    if value is None or value == "":
        return None
    if isinstance(value, str):
        cleaned = _clean_text(value)
        return cleaned or None
    return value


def _build_sections(item: dict) -> list[dict]:
    sections = []
    for field, heading, section_type in SECTION_FIELDS:
        value = item.get(field)
        if value and not _is_placeholder(_clean_text(value)):
            sections.append(
                {
                    "heading_path": [heading],
                    "content": _clean_text(value),
                    "metadata": {"section_type": section_type},
                }
            )

    contact_lines = []
    seen_contact: set[str] = set()
    for field, label in CONTACT_FIELDS:
        value = item.get(field)
        if not value:
            continue
        text = _clean_text(value)
        # "접수기관"과 "접수기관명"처럼 같은 값이 두 필드에 들어오는 경우가 있다.
        if not text or _is_placeholder(text) or text in seen_contact:
            continue
        seen_contact.add(text)
        contact_lines.append(f"{label}: {text}")
    if contact_lines:
        sections.append(
            {
                "heading_path": ["문의·접수"],
                "content": "\n".join(contact_lines),
                "metadata": {"section_type": "contact"},
            }
        )

    basis = [item.get(k) for k in LEGAL_BASIS_FIELDS if item.get(k)]
    if basis:
        sections.append(
            {
                "heading_path": ["근거법령"],
                "content": " / ".join(basis),
                "metadata": {"section_type": "legal_basis"},
            }
        )
    return sections


def _load_failed_ids(path: str) -> set[str]:
    p = Path(path)
    if not p.exists():
        return set()
    return set(json.loads(p.read_text(encoding="utf-8")))


def _field_status(has_value: bool, service_id: str, failed_ids: set[str]) -> str:
    if service_id in failed_ids:
        return FieldStatus.FETCH_FAILED.value
    return FieldStatus.PRESENT.value if has_value else FieldStatus.MISSING_SOURCE.value


def build_field_statuses(
    item: dict,
    service_id: str,
    detail_failed_ids: set[str],
    conditions_failed_ids: set[str],
) -> dict[str, str]:
    """섹션 필드·근거법령 그룹·지원조건(JA코드) 필드의 상태를 계산한다.

    근거법령(법령/행정규칙/자치법규)은 셋 중 하나만 있어도 정상이므로 OR
    조건으로 판단하고, 개별 필드 단위로는 결측 경고를 만들지 않는다.
    """
    statuses: dict[str, str] = {}

    for field, _, section_type in SECTION_FIELDS:
        value = item.get(field)
        has_value = bool(value) and not _is_placeholder(_clean_text(str(value)))
        statuses[section_type] = _field_status(has_value, service_id, detail_failed_ids)

    if service_id in detail_failed_ids:
        statuses["contact"] = FieldStatus.FETCH_FAILED.value
    elif any(item.get(field) for field, _ in CONTACT_FIELDS):
        statuses["contact"] = FieldStatus.PRESENT.value
    else:
        statuses["contact"] = FieldStatus.MISSING_SOURCE.value

    if service_id in detail_failed_ids:
        statuses["legal_basis"] = FieldStatus.FETCH_FAILED.value
    elif any(item.get(k) for k in LEGAL_BASIS_FIELDS):
        statuses["legal_basis"] = FieldStatus.PRESENT.value
    else:
        statuses["legal_basis"] = FieldStatus.MISSING_SOURCE.value

    has_conditions = _has_active_support_condition(item)
    statuses["support_conditions"] = _field_status(has_conditions, service_id, conditions_failed_ids)

    return statuses


def convert_one(
    item: dict,
    collected_at: str,
    warnings_out: list[str],
    detail_failed_ids: set[str],
    conditions_failed_ids: set[str],
    sigungu_code_table: dict,
) -> dict | None:
    service_id = item.get("서비스ID")
    if not service_id:
        warnings_out.append("서비스ID 없음, 제외")
        return None

    raw_source_url = item.get("상세조회URL")
    source_url = _canonical_public_source_url(raw_source_url)
    if source_url is None:
        warnings_out.append(f"{service_id}: 공개 가능한 공식 상세 URL이 없어 제외")
        return None
    if source_url != raw_source_url.strip():
        warnings_out.append(
            f"{service_id}: 상세 URL을 공개 가능한 canonical HTTPS URL로 정규화"
        )

    sections = _build_sections(item)
    if not sections:
        warnings_out.append(f"{service_id}: 본문 없음, 제외")
        return None

    content = "\n".join(f"{s['heading_path'][-1]}\n{s['content']}" for s in sections)
    content_hash = _compute_content_hash(content)
    source_updated_at = _normalize_updated_at(item.get("수정일시"))
    if item.get("수정일시") and source_updated_at is None:
        warnings_out.append(f"{service_id}: 수정일시 형식 인식 불가({item.get('수정일시')!r}), None 처리")
    version = source_updated_at or content_hash[:16]
    doc_id = f"subsidy:{service_id}:{version}"

    field_statuses = build_field_statuses(item, service_id, detail_failed_ids, conditions_failed_ids)

    # 결측이 "원천 결측"인지 "조회 실패로 못 가져온 것"인지 구분해서 문서별로 기록한다.
    doc_parse_warnings: list[str] = []
    if service_id in detail_failed_ids:
        doc_parse_warnings.append(
            "상세조회(serviceDetail) API 호출 실패 — 지원내용/법령 등 상세 필드가 원천 결측이 "
            "아니라 조회 실패로 누락됐을 수 있음"
        )
    if service_id in conditions_failed_ids:
        doc_parse_warnings.append(
            "지원조건조회(supportConditions) API 호출 실패 — JA코드(연령·소득 등 조건)가 원천 "
            "결측이 아니라 조회 실패로 누락됐을 수 있음"
        )

    region = extract_region(item.get("소관기관명"), sigungu_code_table)
    if region["region_scope"] == "unknown":
        doc_parse_warnings.append(
            "소관기관명에서 지역 범위를 확정하지 못해 region_scope=unknown으로 보존"
        )

    age_start, age_end, age_source = extract_age_metadata(item)
    support_conditions, support_condition_codes = collect_support_conditions(item)

    return {
        "schema_version": "1.0",
        "doc_id": doc_id,
        "source_type": "subsidy",
        "source_name": "대한민국 공공서비스(혜택) 정보",
        "source_id": service_id,
        "source_url": source_url,
        "title": item.get("서비스명") or "",
        "content": content,
        "sections": sections,
        "collected_at": collected_at,
        "source_updated_at": source_updated_at,
        # effective_from/effective_to는 rag_design.contracts.Document에서 ISO-8601
        # 날짜 문자열만 허용한다(date.fromisoformat으로 검증). 실제 "신청기한" 값은
        # "상시신청", "주택도시기금 주거안정 월세대출 규정에 따름", "공고에 따름"처럼
        # 대부분 날짜가 아닌 서술형 텍스트라서 여기 억지로 넣으면 검증에서 깨진다.
        # 원문 값은 버리지 않고 metadata["application_deadline_raw"]와 "신청기한"
        # 섹션(sections)에 그대로 보존한다.
        "effective_from": None,
        "effective_to": None,
        "license": LICENSE,
        "content_hash": content_hash,
        "metadata": {
            "organization": item.get("소관기관명") or "",
            # serviceDetail API의 "신청기한" 원문 값을 가공 없이 그대로 저장.
            "application_deadline_raw": item.get("신청기한") or None,
            "region_scope": region["region_scope"],
            "region_names": region["region_names"],
            "region_sido": region["sido"],
            "region_sigungu": region["sigungu"],
            "region_sido_code": region["sido_code"],
            "region_sigungu_code": region["sigungu_code"],
            "service_category": item.get("서비스분야") or "",
            "public_detail_url": source_url,
            "age_start": age_start,
            "age_end": age_end,
            "age_basis": "international_age" if age_source else None,
            "age_source": age_source,
            "field_status": field_statuses,
            # 분류값·URL·집계값. 임베딩하지 않고 그대로 보존한다.
            **{
                key: _passthrough_value(item.get(field))
                for field, key in PASSTHROUGH_METADATA_FIELDS
            },
            # 지원조건조회(supportConditions) JA 코드 전체 + 켜진 코드 목록.
            "support_conditions": support_conditions,
            "support_condition_codes": support_condition_codes,
        },
        "parse_warnings": doc_parse_warnings,
        "sensitive_data_status": "clear",
    }


def annotate_cross_service_duplicates(documents: list[dict]) -> int:
    """같은 content_hash를 가진 서로 다른 서비스ID를 찾아 metadata에 표시만 한다.

    삭제·제외는 하지 않는다 — 서비스ID가 다르면 실제로는 서로 다른 제도일 수
    있기 때문이다. 반환값은 중복이 표시된 문서 수(집계용).
    """
    by_hash: dict[str, list[str]] = defaultdict(list)
    for doc in documents:
        by_hash[doc["content_hash"]].append(doc["source_id"])

    flagged = 0
    for doc in documents:
        siblings = sorted({sid for sid in by_hash[doc["content_hash"]] if sid != doc["source_id"]})
        if siblings:
            doc["metadata"]["duplicate_content_of_source_ids"] = siblings
            doc["parse_warnings"] = list(doc["parse_warnings"]) + [
                f"서로 다른 서비스ID({', '.join(siblings)})와 본문 내용 동일 — 삭제하지 않고 보존"
            ]
            flagged += 1
    return flagged


def run() -> None:
    merged_path = Path(MERGED_PATH)
    items = json.loads(merged_path.read_text(encoding="utf-8"))
    collected_at = datetime.fromtimestamp(merged_path.stat().st_mtime).astimezone().isoformat()

    detail_failed_ids = _load_failed_ids(DETAIL_FAILED_PATH)
    conditions_failed_ids = _load_failed_ids(CONDITIONS_FAILED_PATH)
    sigungu_code_table = load_sigungu_code_table(SIGUNGU_CODE_CSV)

    documents = []
    all_warnings: list[str] = []

    for item in items:
        warnings: list[str] = []
        doc = convert_one(
            item,
            collected_at,
            warnings,
            detail_failed_ids,
            conditions_failed_ids,
            sigungu_code_table,
        )
        all_warnings.extend(warnings)
        if doc is not None:
            documents.append(doc)

    duplicate_count = annotate_cross_service_duplicates(documents)

    excluded = len(items) - len(documents)

    Path(OUT_JSONL).parent.mkdir(parents=True, exist_ok=True)
    with open(OUT_JSONL, "w", encoding="utf-8") as f:
        for doc in documents:
            f.write(json.dumps(doc, ensure_ascii=False) + "\n")

    Path(OUT_PARSE_WARNINGS).write_text(
        json.dumps(all_warnings, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    manifest = {
        "manifest": {
            "schema_version": "1.0",
            "source_type": "subsidy",
            "document_count": len(documents),
            "collected_at": collected_at,
            "source_dataset_url": SOURCE_DATASET_URL,
            "license": LICENSE,
            "excluded_count": excluded,
            "parse_error_count": len(all_warnings),
        },
        "document_card": {
            "source_type": "subsidy",
            "source_name": "대한민국 공공서비스(혜택) 정보",
            "source_dataset_url": SOURCE_DATASET_URL,
            "license": LICENSE,
            "document_count": len(documents),
            "collection_scope": "보조금24 공개 서비스 전체 목록(serviceList/serviceDetail/supportConditions 병합)",
            "cleaning_method": (
                "공백/개행 정규화, 빈 섹션 제거, 지원조건 JA0110/JA0111 연령 정규화, "
                "JA 연령이 없을 때 지원대상/선정기준의 명시적 N세 범위만 보수적으로 추출"
            ),
            "chunking_method": "서비스 섹션(지원대상/선정기준/지원내용/신청방법/신청기한/근거법령) 경계 우선",
            "exclusion_criteria": ["서비스ID 없음", "공식 도메인(gov.kr 등) URL 아님", "본문 없음"],
            "update_policy": "source_updated_at 기준 버전 보존",
            "region_extraction": (
                "소관기관명 텍스트에서 시도/시군구를 정규식으로 추출(region_utils.py). "
                "명시적으로 확인한 중앙기관은 national/['전국'], 시도/시군구는 "
                "regional과 계층형 region_names로 기록한다. 확정할 수 없으면 unknown/[]"
            ),
            "missing_vs_failed": (
                "상세조회/지원조건조회 API 호출이 실패한 서비스ID는 실패 목록"
                "(gov24_*_failed_ids.json)으로 별도 기록하고, 해당 문서의 metadata.field_status와 "
                "parse_warnings에 '조회 실패로 누락'임을 명시해 원천 결측(missing_source)과 구분한다"
            ),
            "duplicate_policy": (
                f"서로 다른 서비스ID의 동일 본문 {duplicate_count}건을 "
                "metadata.duplicate_content_of_source_ids로 표시했고, 삭제하지 않고 그대로 보존한다"
            ),
            "parse_warnings_log": Path(OUT_PARSE_WARNINGS)
            .relative_to(PROJECT_ROOT)
            .as_posix(),
            "rights_reviewed": True,
            "sensitive_data_reviewed": True,
        },
    }
    Path(OUT_MANIFEST).write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    Path(SAMPLE_OUT).parent.mkdir(parents=True, exist_ok=True)
    with open(SAMPLE_OUT, "w", encoding="utf-8") as f:
        for doc in documents[:SAMPLE_SIZE]:
            f.write(json.dumps(doc, ensure_ascii=False) + "\n")

    print(f"변환 완료: {len(documents)}건 (제외 {excluded}건, 중복 표시 {duplicate_count}건)", flush=True)
    print(f"전체: {OUT_JSONL}", flush=True)
    print(f"매니페스트: {OUT_MANIFEST}", flush=True)
    print(f"경고 로그: {OUT_PARSE_WARNINGS} ({len(all_warnings)}건)", flush=True)
    print(f"샘플({SAMPLE_SIZE}건): {SAMPLE_OUT}", flush=True)


if __name__ == "__main__":
    run()
