"""Streamlit 등 프론트엔드가 이 모듈 하나만 가져다 쓰면 되는 진입점.

Streamlit 앱 자체는 **다른 브랜치에서 개발 중**이다(2026-08-31). 이 브랜치는
그 앱이 호출할 서비스 계층까지만 담당하므로, 여기서 화면 코드를 만들지
말고 ``ask()``/``answer_followup()``의 반환 스키마를 계약으로 유지할 것 -
필드를 지우거나 이름을 바꾸면 다른 브랜치가 깨진다.

이 파일은 새 로직을 만들지 않는다 - ``scripts/interactive_console_chat.py``가
콘솔에서 하던 일(실제 vectorDB 연결, ``HF_TOKEN`` 기반 LLM 클라이언트 구성,
``run_graph``/``resume_graph`` 호출)을 그대로 재사용하면서, 반환값을
프론트엔드가 화면을 그릴 수 있는 구조화된 dict로 바꿔주는 얇은 레이어다.
vectorDB 연결/LLM 클라이언트 생성 로직은 원래 ``interactive_console_chat.py``
안에 있었는데, 이 모듈로 옮기고 그 스크립트는 여기서 다시 가져다 쓰도록
바꿨다(같은 로직이 두 곳에 따로 있으면 나중에 한쪽만 고치고 잊어버리기
쉬워서, 한 군데로 모았다).

공개 함수 두 개면 된다:

    from src.rag_chatbot.service import ask, answer_followup

    response = ask("우리 아이가 5살인데 유치원비 지원되는 정책 있나요?", session_id)
    if response["status"] == "needs_input":
        # N3가 하드 게이트 슬롯(지역/성별/소득구간/장애여부/취업상태)을
        # 더 물어야 하는 상태. response["question"]을 보여주고, 사용자
        # 답변을 다시 answer_followup(session_id, 답변)으로 넘긴다.
        ...
    else:
        # response["policies"]가 정책 카드 리스트, response["final_answer"]가
        # 최종 안내 문장. 아래 "반환 형태" 절 참고.
        ...

## 실행 환경

``rag_design``/``src.rag_chatbot``를 import할 수 있어야 하므로, 레포 루트가
``sys.path``에 있어야 한다(``scripts/*.py``가 쓰는 것과 같은 관례:
``PYTHONPATH=.;src`` 또는 레포 루트에서 실행). Streamlit 앱을 레포 루트가
아닌 다른 위치에서 띄우는 경우를 대비해, 이 모듈은 import되는 순간 레포
루트를 ``sys.path``에 한 번만 방어적으로 추가한다(아래 코드 참고) - 이미
PYTHONPATH가 잡혀 있으면 아무 효과 없는 안전한 중복 삽입 방지 처리다.

## LLM 연결

``.env``(또는 셸 환경변수)의 ``HF_TOKEN``이 있으면 N5(claim_plan)/
N9(eligibility_verdict)/N10(benefit_calculator)/N13(answer_generation) 네
곳에 ``HuggingFaceInferenceClient``를 실제로 붙인다 - 이 네 곳이 현재
그래프에서 LLM을 주입할 수 있는 자리 전부다(2026-08-31 기준 코드 직접 확인:
N1 slot_parser·N7 evidence_gate는애초에 llm_client 인자 자체가 없다).
모델 이름은 ``LLM_MODEL_NAME`` 환경변수로 지정한다(예전 이름
``LLM_HF_MODEL``도 하위 호환으로 계속 읽는다 - 둘 다 없으면
``_DEFAULT_HF_MODEL``). ``HF_TOKEN``이 없으면 조용히 규칙 기반/템플릿
경로로만 동작한다(그래프가 LLM 없이도 항상 끝까지 도는 성질은 그대로).

## 반환 형태 (ChatResponse)

두 함수 모두 같은 모양의 dict를 돌려준다 - 프론트엔드는 ``status``만 보고
분기하면 된다.

    # 슬롯이 더 필요한 경우 (N3 interrupt)
    {"status": "needs_input", "question": "...", "session_id": "...",
     "missing_slots": [...]}

    # 끝까지 실행된 경우
    {"status": "answered", "answer_status": "complete"|"partial"|"abstained",
     "final_answer": "...", "final_citations": [...],
     "policies": [PolicyView, ...], "session_id": "..."}

``PolicyView`` 한 건은 첨부받은 두 화면(추천 결과 리스트 / 정책 상세)을
한 dict로 같이 그릴 수 있게 설계했다 - 리스트 화면은 상위 필드만, 상세
화면은 ``detail`` 아래 필드까지 쓰면 된다.

    {
        "rank": 1,                      # 리스트에서의 순서(1부터) - 충족 우선, 그 다음 금액 큰 순
        "policy_id": "...",              # 안정적인 정책 ID (source_id)
        "title": "영유아보육료 지원",      # 청크 원문 첫 줄에서 뽑음(대체 필드 없음)
        "badge": "가장 적합"|"자격 충족"|"확인 필요"|"자격 미충족",
        "eligibility_status": "충족"|"미충족"|"미확인",
        "eligibility_reasons": [...],
        "amount": 280000.0 | None,       # 원 단위 숫자. 주기(월/연/1회)는 모름 - 아래 "한계" 참고
        "amount_label": "월 최대 280,000원 (총 3,360,000원)" | "지원금액 확인 필요",
        "duplicate_status": "가능"|"불가"|"조건부"|"미확인",
        "duplicate_note": "..." | None,
        "needs_confirmation": ["..."],   # 시스템이 스스로 판정 못해 사람이 더 확인해야 하는 사유들
        "related_law": [{"law_name":..., "source_url":...}, ...],
        "detail": {
            "purpose": "..." | None,             # 목적
            "support_target": "..." | None,       # 지원대상
            "eligibility_criteria": "..." | None,  # 선정기준
            "support_details": "..." | None,       # 지원내용
            "application_method": "..." | None,    # 신청방법
            "application_period": "..." | None,    # 신청기한
            "legal_basis": "..." | None,           # 근거법령
            "required_documents": "..." | None,           # 구비서류
            "required_documents_official": "..." | None,  # 공무원 확인 구비서류
            "required_documents_self": "..." | None,      # 본인확인 필요 구비서류
            "region_names": [...] | None,
            "region_scope": "national"|"regional"|"unknown" | None,
            "age_start": int | None,
            "age_end": int | None,
            "organization": "..." | None,
            "source_url": "..." | None,
            "source_name": "..." | None,
        },
    }

## 한계 (숨기지 않음 - docs/PROJECT_COMPLIANCE.md)

- **O/X 재질문은 구현하지 않기로 확정했다(2026-08-31 팀 결정).** 첨부 이미지의
  "추가 필요 정보" O/X 질문(예: "기초생활수급자이신가요?")은 정책별로 한 번 더
  되묻고 그 답을 반영해 재판정하는 인터랙션인데, 현재 그래프(N1~N14)에는 그
  재질문 루프가 없다. N3는 정책 검색 "이전" 하드 게이트 슬롯(지역/생년월일/
  성별/소득구간/장애여부/취업상태)만 되묻는다. 이번 범위에서는 "미확인" 판정
  사유와 검증 범위를 ``needs_confirmation``에 텍스트로 노출하는 것까지만
  한다 - 프론트엔드는 이 필드를 "추가 확인이 필요한 항목" 안내로 렌더링하고,
  O/X 버튼은 만들지 않는다.
- ``eligibility_status``("충족")만 화면에 띄우면 **"모든 자격 조건을 만족한다"로
  읽힌다.** N4는 정상 raw 지원조건이 있는 서비스에 한해 명확히 대응되는
  성별·소득·취업·장애 조건으로 후보를 먼저 거르지만, N9의 구조화된 검증
  범위는 문서 metadata에 있는 연령 기준뿐이다. ``verification_checked``/
  ``verification_unchecked``/``verification_note``를 함께 내려보내니 **정책
  카드에 반드시 같이 노출할 것.** 최종 자격 확인에는 원문 확인이 필요하다.
- ``amount_label``은 이제 지원 주기와 한도 여부를 함께 표기한다(2026-08-31).
  N10이 원문에서 "월/연/1회", "최대/한도", "1인당/가구당"을 읽어 넘겨주고,
  월 단가와 지원 개월수가 둘 다 명시된 경우에만 총액까지 계산한다
  (예: ``"월 최대 200,000원 (총 2,400,000원)"``). 다만 원문에 주기가 안
  적혀 있으면 여전히 ``None``이고, **기간을 모르는데 12를 곱하지 않는다.**
- ``detail`` 섹션들은 ``state["subsidy_chunks"]``(의미 검색으로 찾은 청크
  일부)가 아니라, 정책 ID당 7개 section_type을 vectorDB에서 직접 재검색해서
  채운다(``result_assembly.py``의 ``_find_related_law``와 같은 패턴) - 이래야
  질문과 무관해 애초에 검색 안 된 섹션도 상세 화면에 다 나온다. 다만 그
  섹션 자체가 원천 데이터에 없으면(``field_status``가 missing/fetch_failed)
  ``None``으로 빠진다 - 지어내지 않는다.
- (2026-08-31 수정 완료, 기록 남김) ``result_assembly.py``의
  ``_find_related_law``와 N9/N10/N11이 전부 ``metadata_equals={"doc_id":
  policy_id, ...}``로 필터링하고 있었는데, ``policy_id``는 실제로는
  ``chunk.metadata["source_id"]``이고 ``doc_id``(``f"subsidy:{{service_id}}:
  {{version}}"``)와 다른 값이라 이 필터가 프로덕션에서 구조적으로 단 한 번도
  매치되지 않았다 - 그 결과 실제 vectorDB로 돌리면 자격판정이 항상
  ``"미확인"``으로만 나오는 심각한 버그였다(사용자가 직접 돌려서 10/10
  정책이 전부 미확인인 걸로 발견). 4개 프로덕션 파일 전부
  ``"source_id"``로 고쳤고, 이를 마스킹하던 테스트 픽스처들도 같이 고쳐
  실제로 이 버그를 잡아낼 수 있게 했다(자세한 내용은 프로젝트 메모리
  streamlit_service.md 참고). 이 모듈의 ``_fetch_policy_detail``은 처음부터
  ``"source_id"``로 필터링해서 애초에 이 버그의 영향을 받지 않았다.
"""

from __future__ import annotations

from collections.abc import Mapping
from contextlib import ExitStack, nullcontext
from datetime import date
import sys
from pathlib import Path
from threading import Lock
from typing import Any, Literal, TypedDict

# Streamlit 등 다른 위치에서 이 모듈을 import해도 rag_design/src.rag_chatbot를
# 찾을 수 있도록, 레포 루트를 한 번만 방어적으로 sys.path에 추가한다.
# (scripts/*.py가 쓰는 것과 같은 관례 - 이미 PYTHONPATH가 잡혀 있으면
# 아무 효과 없다.)
_REPO_ROOT = Path(__file__).resolve().parents[2]
if str(_REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(_REPO_ROOT))

import os

from dotenv import load_dotenv

from rag_design.contracts import RegionScope, SUBSIDY_DETAIL_SECTIONS, SourceType
from rag_design.embeddings import (
    HashEmbeddingProvider,
    SentenceTransformerKoreanProvider,
)
from rag_design.vector_store import (
    ChromaVectorStore,
    CollectionNotFoundError,
    VectorSearchFilter,
    VectorStoreConfig,
)

from .graph import build_graph, resume_graph, run_graph
from .graph.nodes.slot_parser import normalize_region_input
from .graph.slot_schema import (
    UNKNOWN,
    HouseholdType,
    is_valid_slot_value,
    parse_birth_date,
)
from .graph.policy_conditions import load_policy_user_types, load_support_conditions
from .graph.slot_schema import UNKNOWN
from .llm import (
    OllamaClient,
    HuggingFaceInferenceClient,
    RecordingLLMClient,
    RunPodServerlessClient,
)
from .timing import TIMER, node_title

# 레포 루트의 .env에서 HF_TOKEN/LLM_MODEL_NAME 등을 읽는다(이미 셸에 직접
# 설정돼 있으면 그 값이 우선한다 - load_dotenv 기본값 override=False).
load_dotenv(_REPO_ROOT / ".env")

# 실제 서비스 vectorDB. rag_design/index_policy.py·scripts/manual_test_chain.py
# 의 실제 색인 경로/collection_prefix와 동일하게 맞춘다 - 다르게 쓰면 빈
# 컬렉션을 새로 만들 뿐 실제 데이터에 연결되지 않는다.
_REAL_VECTOR_DB_PATH = _REPO_ROOT / "data" / "vector_db"
_REAL_SUPPORT_CONDITIONS_PATH = (
    _REPO_ROOT / "data" / "raw" / "gov24_support_conditions.json"
)
# 2026-09-11 추가: 사용자구분("개인"/"법인/시설/단체" 등)은 위 JA
# 코드 sidecar에는 없고 처리된 문서 코퍼스에만 있다(policy_conditions.
# load_policy_user_types docstring 참고).
_REAL_SUBSIDY_DOCUMENTS_PATH = (
    _REPO_ROOT / "data" / "processed" / "subsidy_documents.jsonl"
)
_REAL_COLLECTION_PREFIX = "bokji_rag"
_HASH_EMBEDDING_DIMENSION = 128
_KOREAN_EMBEDDING_MODEL = "intfloat/multilingual-e5-base"
_KOREAN_EMBEDDING_DIMENSION = 768

# HF_TOKEN이 있는데 LLM_MODEL_NAME/LLM_HF_MODEL을 안 정한 경우의 기본 모델 -
# 세 후보(client.py 상단 docstring 참고) 중 가장 작아서 HuggingFace 서버리스
# Inference API에 "warm"하게 떠 있을 가능성이 제일 높은 걸로 잡았다.
_DEFAULT_HF_MODEL = "Bllossom/llama-3.2-Korean-Bllossom-3B"


def build_embedding_provider():
    """검색에 쓸 임베딩 provider를 만든다.

    서비스 기본은 ``SentenceTransformerKoreanProvider``
    (intfloat/multilingual-e5-base, 768차원)이다. 색인과 검색의 provider가
    다르면 벡터 공간 자체가 달라지므로 ``ChromaVectorStore`` fingerprint가
    연결을 차단한다. 테스트·오프라인 스모크는 ``EMBEDDING_PROVIDER=hash``로
    기존 ``HashEmbeddingProvider``(local-hash-v1:128)를 계속 쓸 수 있다.

    재색인 방법(레포 루트에서, sentence-transformers 설치 필요):
        python -m rag_design.vector_cli \
            --persist-directory data/vector_db --collection-prefix bokji_rag \
            --embedding korean index-documents \
            --source subsidy --snapshot-id <id> \
            --documents <documents.jsonl>
    """

    provider_name = (os.environ.get("EMBEDDING_PROVIDER") or "korean").strip().lower()
    if provider_name == "hash":
        return HashEmbeddingProvider(
            int(os.environ.get("EMBEDDING_DIMENSION") or _HASH_EMBEDDING_DIMENSION)
        )
    if provider_name == "korean":
        return SentenceTransformerKoreanProvider(
            os.environ.get("EMBEDDING_MODEL_NAME") or _KOREAN_EMBEDDING_MODEL,
            dimension=int(
                os.environ.get("EMBEDDING_DIMENSION") or _KOREAN_EMBEDDING_DIMENSION
            ),
        )
    raise SystemExit(
        f"EMBEDDING_PROVIDER={provider_name!r}는 지원하지 않습니다 "
        "('hash' 또는 'korean')."
    )


def connect_store() -> ChromaVectorStore:
    """실제 서비스 vectorDB(``data/vector_db``)에 연결한다 (색인은 안 함)."""

    if not (_REAL_VECTOR_DB_PATH / "chroma.sqlite3").is_file():
        raise SystemExit(
            f"{_REAL_VECTOR_DB_PATH}에 실제 Chroma DB가 없습니다. "
            "레포 루트에 사전 구축된 vectorDB가 "
            "있는 컴퓨터에서 실행했는지 확인해 주세요."
        )
    return ChromaVectorStore(
        build_embedding_provider(),
        VectorStoreConfig(
            persist_directory=_REAL_VECTOR_DB_PATH,
            collection_prefix=_REAL_COLLECTION_PREFIX,
        ),
    )


def build_llm_client() -> RecordingLLMClient | None:
    """선택한 백엔드로 N1/N5/N9/N10/N13에 실제로 붙일 LLM 클라이언트를
    만든다. HF/RunPod 인증정보가 없으면 ``None``을 반환하여 기존 규칙 기반/
    템플릿 경로를 유지한다. Ollama를 선택하면 명시적인 모델 이름이 필요하다.

    백엔드 선택(``LLM_BACKEND`` 환경변수):
    - ``ollama``: 로컬 Ollama. ``LLM_MODEL_NAME`` 필수, HF 토큰 불필요.
      ``OLLAMA_BASE_URL``은 loopback만 허용한다. ``LLM_DISABLE_THINKING=1``은
      /api/show capabilities에 thinking이 있을 때만 think=False를 보낸다.
    - ``runpod``: 파인튜닝 checkpoint를 서빙하는 RunPod Serverless 엔드포인트.
      ``RUNPOD_ENDPOINT_ID`` / ``RUNPOD_API_KEY`` 필요.
    - ``hf`` (기본): HuggingFace Inference Providers. ``HF_TOKEN`` 필요.
      모델은 ``LLM_MODEL_NAME`` → 옛 이름 ``LLM_HF_MODEL`` → ``_DEFAULT_HF_MODEL``.
    """

    backend = (os.environ.get("LLM_BACKEND") or "hf").strip().lower()

    if backend == "ollama":
        return RecordingLLMClient(OllamaClient(
            model=os.environ.get("LLM_MODEL_NAME") or "",
            base_url=os.environ.get("OLLAMA_BASE_URL") or "http://localhost:11434",
            timeout_seconds=float(os.environ.get("LLM_TIMEOUT_SECONDS") or 120.0),
            num_predict=int(os.environ.get("LLM_MAX_NEW_TOKENS") or 1024),
            num_ctx=int(os.environ.get("OLLAMA_NUM_CTX") or 4096),
            disable_thinking=os.environ.get("LLM_DISABLE_THINKING") == "1",
        ))

    if backend == "runpod":
        if not (os.environ.get("RUNPOD_ENDPOINT_ID") and os.environ.get("RUNPOD_API_KEY")):
            return None
        return RecordingLLMClient(
            RunPodServerlessClient(
                timeout_seconds=float(os.environ.get("LLM_TIMEOUT_SECONDS") or 120.0),
            )
        )
    if backend not in {"hf", "huggingface"}:
        raise ValueError("LLM_BACKEND must be hf, huggingface, runpod, or ollama")

    token = os.environ.get("HF_TOKEN") or os.environ.get("HUGGINGFACE_TOKEN")
    if not token:
        return None
    model = (
        os.environ.get("LLM_MODEL_NAME")
        or os.environ.get("LLM_HF_MODEL")
        or _DEFAULT_HF_MODEL
    )
    # 토큰 예산과 "생각 끄기"를 환경변수로 조절할 수 있게 한다.
    #
    # 왜: 추론형 모델(Qwen3.5 계열)은 답을 쓰기 전에 내부 사고에 토큰을 크게
    # 써서 호출 하나가 수십 초씩 걸린다(실측: N1 한 번에 50초). 기본
    # max_new_tokens=8192는 그 사고 길이를 감당하려고 올려둔 값이라,
    # 비추론형 모델을 쓰면 훨씬 낮춰도 되고 그만큼 빨라진다.
    max_new_tokens = int(os.environ.get("LLM_MAX_NEW_TOKENS") or 8192)

    # LLM_DISABLE_THINKING=1이면 provider에 "사고 과정을 끄라"고 요청한다.
    # Qwen3 계열 chat template이 지원한다고 알려진 파라미터인데, 이
    # HuggingFace Inference Providers 라우팅 경로에서 실제로 먹히는지는
    # 검증하지 못했다(샌드박스에서 huggingface.co에 접속할 수 없음).
    # 안 먹히면 조용히 무시되거나 에러가 나므로, 켠 뒤 체감 속도와
    # llm_status의 평균 호출 시간을 비교해서 판단할 것.
    extra_body = None
    if os.environ.get("LLM_DISABLE_THINKING") == "1":
        extra_body = {"chat_template_kwargs": {"enable_thinking": False}}

    # RecordingLLMClient로 감싼다. 노드들은 LLM 호출이 실패해도 규칙 기반으로
    # 조용히 폴백하기 때문에, 감싸지 않으면 "LLM이 한 번도 안 돌았는데 결과는
    # 멀쩡히 나오는" 상태를 아무도 모른다. 여기 모인 실패 사유를
    # ChatResponse["llm_status"]로 화면까지 올린다.
    return RecordingLLMClient(
        HuggingFaceInferenceClient(
            model=model, max_new_tokens=max_new_tokens, extra_body=extra_body
        )
    )


# 그래프/store/llm_client는 만드는 비용이 크다(vectorDB 연결, LLM 클라이언트
# 구성) - 요청마다 새로 만들지 않고 프로세스에서 한 번만 만들어 재사용한다.
# Streamlit에서는 get_graph()를 @st.cache_resource로 한 번 더 감싸는 걸
# 권장한다(스크립트 재실행마다 이 캐시가 초기화되는 걸 막기 위해).
_runtime_cache: dict[str, Any] = {}
# ponytail: 프로세스당 한 번뿐인 startup에는 전역 잠금 하나면 충분하다.
_runtime_lock = Lock()


def get_graph() -> Any:
    """조립된 그래프를 반환한다(프로세스당 한 번만 조립)."""

    global _runtime_cache
    if "graph" not in _runtime_cache:
        with _runtime_lock:
            if "graph" not in _runtime_cache:
                # 이 세 단계를 따로 재는 이유: "첫 실행이 느리다"의 범인이
                # vectorDB 인덱스 로딩인지 그래프 조립인지 구분되지 않으면
                # 엉뚱한 데를 최적화하게 된다.
                with TIMER.measure("startup:vectordb_connect"):
                    store = connect_store()
                with TIMER.measure("startup:llm_client"):
                    llm_client = build_llm_client()
                with TIMER.measure("startup:support_conditions"):
                    support_conditions = load_support_conditions(
                        _REAL_SUPPORT_CONDITIONS_PATH
                    )
                with TIMER.measure("startup:policy_user_types"):
                    user_types = load_policy_user_types(
                        _REAL_SUBSIDY_DOCUMENTS_PATH
                    )
                with TIMER.measure("startup:graph_build"):
                    graph = build_graph(
                        store,
                        llm_client=llm_client,
                        support_conditions=support_conditions,
                        user_types=user_types,
                    )
                _runtime_cache = {
                    "store": store,
                    "llm_client": llm_client,
                    "support_conditions": support_conditions,
                    "user_types": user_types,
                    "graph": graph,
                }
    return _runtime_cache["graph"]


def get_store() -> ChromaVectorStore:
    """상세 화면용 섹션 재검색에 쓰는 store. ``get_graph()``와 같은 인스턴스."""

    get_graph()
    return _runtime_cache["store"]


def get_llm_client() -> Any:
    """정책 상세 문의 경량 응답(``light_followup``) 등이 재사용하는 공유 LLM
    클라이언트. ``get_graph()``와 같은 인스턴스이며 HF_TOKEN이 없으면 ``None``."""

    get_graph()
    return _runtime_cache.get("llm_client")


class PolicyDetail(TypedDict, total=False):
    purpose: str | None
    support_target: str | None
    eligibility_criteria: str | None
    support_details: str | None
    application_method: str | None
    application_period: str | None
    legal_basis: str | None
    region_names: list[str] | None
    region_scope: str | None
    age_start: int | None
    age_end: int | None
    organization: str | None
    source_url: str | None
    source_name: str | None


class PolicyView(TypedDict, total=False):
    rank: int
    policy_id: str
    title: str
    badge: str
    eligibility_status: str
    eligibility_reasons: list[str]
    # 이 판정이 실제로 대조한 조건 / 대조하지 못한 조건, 그리고 그걸 한 문장으로
    # 정리한 안내. eligibility_status만 화면에 띄우면 "충족"이 "모든 조건 만족"
    # 으로 읽히므로, 카드에 이 문구를 함께 노출할 것.
    verification_checked: list[str]
    verification_unchecked: list[str]
    verification_note: str | None
    amount: float | None
    amount_label: str
    # 금액의 성격. amount만 띄우면 월/연/1회, 확정/상한 구분이 안 된다.
    # amount_label에 이미 반영돼 있지만, 화면에서 따로 배지로 쓰고 싶을 때를
    # 위해 원자값도 함께 넘긴다. period: "month"|"year"|"once"|None
    amount_period: str | None
    amount_is_maximum: bool
    amount_per_unit: str | None
    amount_total: float | None
    # "90-110만원"처럼 조건 구분 없는 범위로만 원문에 적혀 있을 때(둘 다
    # 있을 때만 유효, 2026-09-11 추가) - amount는 이때 None이고
    # amount_label에 이미 범위로 반영돼 있다.
    amount_min: float | None
    amount_max: float | None
    # amount_min/amount_max에 근거(개월수/가구원수)가 있을 때만 채워지는
    # 총액 범위(2026-09-11 추가) - amount_total과 짝을 이룬다.
    total_amount_min: float | None
    total_amount_max: float | None
    duplicate_status: str
    duplicate_note: str | None
    # 조항의 성격("other"/"household"/"header"/None)과, 그에 따라 화면에
    # 어떤 안내를 낼지 정하는 재료. 셋을 한 문구로 뭉뚱그리면 "1가구 1회"가
    # "다른 제도와 중복 불가"로 읽힌다(N11 duplicate_benefit.py 참고).
    duplicate_clause_kind: str | None
    # 같은 답변에 함께 나온 정책 중 중복수급이 안 되는 것들.
    duplicate_conflicts: list[dict]
    # 신청 횟수·가구 단위 제한 원문. 중복수급과는 별개 안내로 낸다.
    household_limit_clauses: list[str]
    needs_confirmation: list[str]
    related_law: list[dict]
    detail: PolicyDetail


class ChatResponse(TypedDict, total=False):
    status: Literal["needs_input", "answered"]
    session_id: str
    question: str
    missing_slots: list[str]
    answer_status: str | None
    final_answer: str | None
    final_citations: list[dict]
    policies: list[PolicyView]
    # 프론트엔드가 같은 결과를 JSON, 일반 문자열, Markdown 비교표 중 필요한
    # 형식으로 바로 사용할 수 있게 한다. output_json은 직렬화 전 dict다.
    output_json: dict
    output_text: str
    output_markdown: str
    # LLM이 이번 요청에서 실제로 돌았는지. 실패해도 노드들이 규칙 기반으로
    # 폴백해 결과는 정상적으로 나오기 때문에, 이 값을 화면에 표시하지 않으면
    # 사용자는 AI가 판단한 줄 안다. {"enabled", "model", "calls", "successes",
    # "failures", "messages"} 형태.
    llm_status: dict
    # 이번 요청의 단계별 소요 시간과 실제로 지나간 노드 경로.
    # {"phases": [{name, count, total_s, avg_s, share}...],
    #  "node_path": [{node, title, seconds}...]}
    timing: dict


# --- 정책 상세 섹션 재검색 (목적/지원대상/선정기준/지원내용/신청방법/신청기한/근거법령/구비서류) ---
# section_type 목록 자체는 rag_design.contracts.SUBSIDY_DETAIL_SECTIONS가
# 유일한 출처다(streamlit_ui/constants.py의 SECTION_LABELS_KO도 같은 곳에서
# 가져온다) - 검색 힌트 텍스트만 여기서 뽑아 쓴다.
_DETAIL_SECTION_TYPES: list[tuple[str, str]] = [
    (section_type, search_hint) for section_type, search_hint, _ in SUBSIDY_DETAIL_SECTIONS
]


def _extract_title(chunk_text: str) -> str:
    """chunking.py의 prefix 규칙(``f"{제목}\\n지역: ...\\n{heading_path}"``)에서
    첫 줄만 뽑는다."""
    return chunk_text.split("\n", 1)[0].strip()


def _strip_prefix(chunk_text: str) -> str:
    """chunk.text 앞에 붙는 "{제목}\\n지역: ...\\n{heading_path}\\n\\n" prefix를
    떼고 본문만 남긴다. prefix 구분자(빈 줄)가 없으면(형식이 다른 경우)
    원문을 그대로 돌려준다 - 지어내지 않는다."""
    _, sep, body = chunk_text.partition("\n\n")
    return body.strip() if sep else chunk_text.strip()


def _fetch_policy_detail(policy_id: str, store: Any, query_id: str) -> dict:
    """정책 상세 화면에 필요한 섹션 텍스트/메타데이터를 vectorDB에서 직접
    채운다.

    state["subsidy_chunks"]는 N4가 의미 검색으로 찾은 청크 몇 개뿐이라
    (질문과 관련된 섹션만), 상세 화면에 필요한 7개 섹션을 전부 보장하지
    못한다. 그래서 정책 하나당 section_type별로 직접 재검색한다
    (``result_assembly.py``의 ``_find_related_law``와 같은 패턴, 다만
    필터 키는 ``"source_id"``를 쓴다 - 위 모듈 docstring "한계" 절 참고).
    """
    sections: dict[str, str] = {}
    meta: dict = {}
    for section_type, label in _DETAIL_SECTION_TYPES:
        try:
            hits = store.search(
                SourceType.SUBSIDY,
                f"{policy_id} {label}",
                query_id=f"{query_id}-{policy_id}-detail-{section_type}",
                top_k=1,
                search_filter=VectorSearchFilter(
                    metadata_equals={"source_id": policy_id, "section_type": section_type}
                ),
            )
        except CollectionNotFoundError:
            hits = ()
        if not hits:
            continue
        chunk = hits[0].chunk
        sections[section_type] = _strip_prefix(chunk.text)
        if not meta:
            meta = {
                "title": _extract_title(chunk.text),
                "source_url": chunk.metadata.get("source_url"),
                "source_name": chunk.metadata.get("source_name"),
                "organization": chunk.metadata.get("organization"),
                "region_names": chunk.metadata.get("region_names"),
                "region_scope": chunk.metadata.get("region_scope"),
                "age_start": chunk.metadata.get("age_start"),
                "age_end": chunk.metadata.get("age_end"),
            }
    return {"sections": sections, **meta}


_VERDICT_RANK = {"충족": 0, "미확인": 1, "미충족": 2}
# "자격 충족"/"가장 적합"은 과대 주장이었다. N9가 실제로 대조하는 조건은 문서
# metadata에 있는 연령 기준뿐이라, 비장애인에게 장애인 정책이 "자격 충족"으로
# 뜨는 일이 있었다. 뱃지 문구를 "확인한 범위"를 말하는 쪽으로 바꾸고,
# 무엇을 확인/미확인했는지는 verification_* 필드로 화면에 함께 넘긴다.
_VERDICT_BADGE = {
    "충족": "일부 조건 확인",
    "미확인": "확인 필요",
    "미충족": "자격 미충족",
}
# 확인한 조건이 하나도 없는데 "충족"이 나온 경우(문서에 대조할 구조화 기준이
# 아예 없었던 경우) - 가장 약한 근거이므로 따로 표시한다.
_BADGE_NOTHING_CHECKED = "미검증"


def _verification_note(checked: list[str], unchecked: list[str]) -> str | None:
    """이 판정의 검증 범위를 사용자에게 보여줄 한 문장으로 만든다.

    N9가 넘겨준 값만 쓰고 여기서 추측하지 않는다. 옛 형식의 판정처럼 둘 다
    비어 있으면 아무 문구도 만들지 않는다(없는 사실을 지어내지 않기 위함).
    """

    if not checked and not unchecked:
        return None
    if not unchecked:
        return f"{', '.join(checked)} 조건을 확인했습니다."
    if not checked:
        return (
            "이 정책 문서에는 대조할 수 있는 구조화된 기준이 없어 "
            f"{', '.join(unchecked)} 조건을 확인하지 못했습니다. 원문을 직접 확인해주세요."
        )
    return (
        f"{', '.join(checked)} 조건만 확인했습니다. "
        f"{', '.join(unchecked)}은(는) 확인하지 못했으니 원문을 직접 확인해주세요."
    )


_PERIOD_LABELS = {"month": "월", "year": "연", "once": "1회"}
_PER_UNIT_LABELS = {"person": "1인당", "household": "가구당"}


def _won(amount: float) -> str:
    return f"{amount:,.0f}원"


def _format_amount_label(
    amount: float | None, status_note: str | None, benefit: dict | None = None
) -> str:
    """금액을 사용자가 오해 없이 읽을 수 있는 문구로 만든다.

    금액 숫자만 보여주면 "200,000원"이 월인지 연인지 1회인지, 확정인지
    상한인지 알 수 없어서 그만큼 받는다고 읽힌다. 원천 데이터의 42.5%가
    "최대/한도" 표현이라 특히 위험하다. N10이 원문에서 읽어둔 성격
    (``period``/``is_maximum``/``per_unit``/``total_amount``)을 그대로 붙인다.

    예: ``"월 최대 200,000원 (12개월 기준 총 2,400,000원)"``

    amount가 없어도 benefit에 amount_min/amount_max(2026-09-11 추가)가
    둘 다 있으면 범위로 보여준다 - 예: ``"월 900,000원~1,100,000원"``.
    "90-110만원"처럼 조건 구분 없는 범위는 원문에 이미 있는 정보라,
    대표값 하나를 못 고른다고 "지원금액 확인 필요"로 뭉갤 이유가 없다.
    """

    benefit = benefit or {}

    if not isinstance(amount, (int, float)):
        amount_min = benefit.get("amount_min")
        amount_max = benefit.get("amount_max")
        if isinstance(amount_min, (int, float)) and isinstance(amount_max, (int, float)):
            range_parts: list[str] = []
            per_unit = _PER_UNIT_LABELS.get(benefit.get("per_unit") or "")
            if per_unit:
                range_parts.append(per_unit)
            period = _PERIOD_LABELS.get(benefit.get("period") or "")
            if period:
                range_parts.append(period)
            range_parts.append(f"{_won(float(amount_min))}~{_won(float(amount_max))}")
            label = " ".join(range_parts)
            total_min = benefit.get("total_amount_min")
            total_max = benefit.get("total_amount_max")
            if isinstance(total_min, (int, float)) and isinstance(total_max, (int, float)):
                label += f" (총 {_won(float(total_min))}~{_won(float(total_max))})"
            return label
        return status_note or "지원금액 확인 필요"
    parts: list[str] = []
    per_unit = _PER_UNIT_LABELS.get(benefit.get("per_unit") or "")
    if per_unit:
        parts.append(per_unit)
    period = _PERIOD_LABELS.get(benefit.get("period") or "")
    if period:
        parts.append(period)
    if benefit.get("is_maximum"):
        parts.append("최대")
    parts.append(_won(float(amount)))

    label = " ".join(parts)
    total = benefit.get("total_amount")
    if isinstance(total, (int, float)) and float(total) != float(amount):
        label += f" (총 {_won(float(total))})"
    return label


def _build_policy_view(
    policy_id: str, entry: dict, *, store: Any, query_id: str, rank: int, is_top: bool
) -> PolicyView:
    eligibility = entry.get("eligibility") or {}
    verdict = eligibility.get("verdict", "미확인")
    reasons = eligibility.get("reasons", [])

    benefit = entry.get("benefit_amount")
    amount = benefit.get("amount") if benefit else None
    amount_note = entry.get("status_note")
    # st.metric 위젯(streamlit_ui/rendering.py의 _metric)은 짧은 값 한 줄만
    # 보여주도록 만들어졌다. amount가 None이면 amount_note에는 길이가
    # 들쭉날쭉한 문구가 들어갈 수 있다 - LLM이 자유 서술형으로 쓴 사유
    # (예: "이 금액은 융자 한도로 지원금이 아님")이거나, 실패를 숨기지
    # 않는다는 원칙 때문에 그대로 남겨둔 LLM 호출 실패/응답 파싱 실패
    # 메시지(benefit_calculator.py 참고)다. 이걸 그대로 금액 위젯 안에
    # 밀어넣으면 카드마다 레이아웃이 깨지므로, 위젯에는 고정된 짧은
    # 문구만 넣고 실제 사유는 아래에서 needs_confirmation(문장 길이
    # 제약이 없는 자리)으로 옮긴다.
    amount_label = _format_amount_label(amount, None, benefit)

    duplicate = entry.get("duplicate") or {}
    duplicate_status = duplicate.get("status") if duplicate else "미확인"
    # entry["status_note"](amount_note)는 "지원금 계산이 왜 안 됐는지"를
    # 설명하는 문구다(대출 한도라 확정 불가, 정보 부족 등) - 중복수급과는
    # 무관한 사유인데, 예전에는 duplicate가 비어 있으면(그 정책에 중복수급
    # 조항 자체가 없으면) 이 자리로 새어 들어와 "중복수급 안내" 캡션에
    # 금액 사유가 떴다(streamlit_ui/rendering.py의 duplicate_note 캡션
    # 렌더링 참고). 그 정보는 이미 needs_confirmation(위 amount_note 처리
    # 참고)이 올바른 자리에서 보여주고 있으므로, 여기서는 실제 중복수급
    # 조항이 있을 때만 채운다.
    duplicate_note = duplicate.get("condition_note") if duplicate else None
    duplicate_clause_kind = duplicate.get("clause_kind")
    household_limit_clauses = [
        str(item) for item in duplicate.get("household_clauses") or []
    ]

    needs_confirmation: list[str] = []
    if verdict == "미확인":
        needs_confirmation.extend(reasons)
    if not isinstance(amount, (int, float)) and amount_note:
        needs_confirmation.append(amount_note)
    if duplicate_status in ("미확인", "조건부") and duplicate_note:
        needs_confirmation.append(duplicate_note)
    # 자격 미확인 사유와 중복수급 미확인 사유가 우연히 같은 문장일 수 있다
    # (예: 둘 다 "재검색에서 해당 정책 근거를 다시 찾지 못함") - 순서는
    # 유지하면서 중복만 뺀다.
    needs_confirmation = list(dict.fromkeys(needs_confirmation))

    checked = eligibility.get("checked") or []
    unchecked = eligibility.get("unchecked") or []
    if verdict == "충족" and not checked:
        # 아무 조건도 대조하지 못했는데 "충족"이라고 부르면 안 된다.
        badge = _BADGE_NOTHING_CHECKED
    elif is_top and verdict == "충족":
        # "가장 적합"은 쓰지 않는다 - 확인한 조건이 연령뿐인데 최적이라고
        # 단정하는 표현이기 때문. 순위는 rank 필드가 이미 나타낸다.
        badge = "우선 검토"
    else:
        badge = _VERDICT_BADGE.get(verdict, "확인 필요")

    verification_note = _verification_note(checked, unchecked)
    if verification_note and verification_note not in needs_confirmation:
        # 화면의 "추가 확인 필요" 영역에도 올려서, 카드만 보고 판단하는
        # 사용자가 검증 범위를 놓치지 않게 한다.
        needs_confirmation.append(verification_note)

    detail_raw = _fetch_policy_detail(policy_id, store, query_id)
    sections = detail_raw.get("sections", {})

    return {
        "rank": rank,
        "policy_id": policy_id,
        "title": detail_raw.get("title") or policy_id,
        "badge": badge,
        "eligibility_status": verdict,
        "eligibility_reasons": reasons,
        "verification_checked": checked,
        "verification_unchecked": unchecked,
        "verification_note": verification_note,
        "amount": amount,
        "amount_label": amount_label,
        "amount_period": (benefit or {}).get("period"),
        "amount_is_maximum": bool((benefit or {}).get("is_maximum")),
        "amount_per_unit": (benefit or {}).get("per_unit"),
        "amount_total": (benefit or {}).get("total_amount"),
        "amount_min": (benefit or {}).get("amount_min"),
        "amount_max": (benefit or {}).get("amount_max"),
        "total_amount_min": (benefit or {}).get("total_amount_min"),
        "total_amount_max": (benefit or {}).get("total_amount_max"),
        "duplicate_status": duplicate_status,
        "duplicate_note": duplicate_note,
        "duplicate_clause_kind": duplicate_clause_kind,
        # 상대 정책의 "제목"은 다른 뷰가 만들어져야 알 수 있어서 여기서는
        # id만 담고, 뷰를 전부 만든 뒤 _attach_duplicate_conflicts가 채운다.
        "duplicate_conflicts": [
            {"policy_id": str(pid)} for pid in duplicate.get("conflicts_with") or []
        ],
        "household_limit_clauses": household_limit_clauses,
        "needs_confirmation": needs_confirmation,
        "related_law": entry.get("related_law", []),
        "detail": {
            # section_type 키 집합은 _DETAIL_SECTION_TYPES(=SUBSIDY_DETAIL_SECTIONS)
            # 순서를 그대로 따른다 - 새 section_type을 추가했는데 여기 반영을
            # 깜빡해 검색은 되는데 응답엔 안 실리는 일(#48)을 막는다.
            **{section_type: sections.get(section_type) for section_type, _ in _DETAIL_SECTION_TYPES},
            "region_names": detail_raw.get("region_names"),
            "region_scope": detail_raw.get("region_scope"),
            "age_start": detail_raw.get("age_start"),
            "age_end": detail_raw.get("age_end"),
            "organization": detail_raw.get("organization"),
            "source_url": detail_raw.get("source_url"),
            "source_name": detail_raw.get("source_name"),
        },
    }


def _attach_duplicate_conflicts(views: list[PolicyView]) -> None:
    """``duplicate_conflicts``의 각 항목에 상대 정책의 제목을 채운다.

    N11은 policy_id만 알고 제목은 모른다(제목은 chunk 본문에서 뽑는다).
    화면에는 id가 아니라 이름이 나가야 하므로, 같은 응답 안의 뷰들끼리
    id -> title 로 이어 붙인다. 이번 답변에 없는 정책은 id를 그대로 둔다.
    """

    titles = {
        str(view.get("policy_id")): str(view.get("title") or view.get("policy_id"))
        for view in views
    }
    for view in views:
        for conflict in view.get("duplicate_conflicts") or []:
            policy_id = conflict.get("policy_id")
            conflict["title"] = titles.get(policy_id, policy_id)


def _rank_policies(policies: dict[str, dict]) -> list[tuple[str, dict]]:
    """충족을 먼저, 그다음 금액이 큰 순으로 정렬한다(첨부 이미지의 "가장
    적합"이 맨 위에 오는 리스트 순서와 맞추기 위한 휴리스틱 - 정책상
    "가장 적합"의 정의가 따로 있는 건 아니다)."""

    def sort_key(item: tuple[str, dict]) -> tuple[int, float]:
        _, entry = item
        verdict = (entry.get("eligibility") or {}).get("verdict", "미확인")
        benefit = entry.get("benefit_amount")
        amount = benefit.get("amount") if benefit else None
        return (_VERDICT_RANK.get(verdict, 1), -(amount or 0.0))

    return sorted(policies.items(), key=sort_key)


def _llm_status() -> dict:
    """이번 요청에서 LLM이 실제로 돌았는지 요약한다.

    화면에 "AI 분석 적용됨 / 규칙 기반으로만 처리됨"을 정직하게 표시하기 위한
    값이다. LLM이 안 붙었거나 전부 실패했는데도 결과만 멀쩡히 보여주면
    사용자는 AI가 판단한 줄 안다(docs/PROJECT_COMPLIANCE.md - 한계를 숨기지
    않는다).
    """

    client = _runtime_cache.get("llm_client")
    if client is None:
        return {
            "enabled": False,
            "model": None,
            "calls": 0,
            "successes": 0,
            "failures": 0,
            "messages": [
                "HF_TOKEN이 없어 LLM 없이 규칙 기반/템플릿 경로로만 처리했습니다."
            ],
        }
    if not isinstance(client, RecordingLLMClient):
        # 외부에서 직접 주입한 클라이언트 - 기록 기능이 없다.
        return {
            "enabled": True,
            "model": getattr(client, "model", None),
            "calls": None,
            "successes": None,
            "failures": None,
            "messages": [],
        }
    return client.summary()


def _llm_request_scope():
    """공유 client의 기록만 현재 요청에 격리한다."""

    client = _runtime_cache.get("llm_client")
    if isinstance(client, RecordingLLMClient):
        return client.request_scope()
    return nullcontext()


def _timing_report() -> dict:
    """이번 요청에서 어디에 시간이 들었는지.

    ``node_path``는 그래프가 실제로 지나간 노드 순서다 - 조건부 분기가
    있어서 어떤 경로로 갔는지는 실행해봐야만 안다.
    """

    return {
        "phases": TIMER.summary(),
        "node_path": [
            {"node": name, "title": node_title(name), "seconds": seconds}
            for name, seconds in TIMER.path()
        ],
    }


# ── output_json "파악한 정보"용 슬롯값 -> 한글 라벨 ──────────────────
# 화면(streamlit_ui)이 쓰는 라벨과 같은 어휘다. 슬롯 코드값("under_30")을
# 그대로 JSON에 노출하면 이 응답을 받는 쪽이 매핑을 또 만들어야 하므로,
# 사람이 읽는 문자열까지 여기서 만들어 준다.
_GENDER_KO = {"male": "남성", "female": "여성"}
_INCOME_KO = {
    "under_30": "기초생활수급 수준(중위소득 30% 이하)",
    "pct_30_50": "차상위 수준(중위소득 30~50%)",
    "pct_50_75": "중위소득 50~75%",
    "pct_75_100": "중위소득 75~100%",
    "pct_100_150": "중위소득 100~150%",
    "over_150": "중위소득 150% 초과",
}
_DISABILITY_KO = {"registered": "장애 등록", "not_registered": "장애 없음"}
_EMPLOYMENT_KO = {
    "employed": "재직",
    "job_seeking": "구직",
    "self_employed": "자영업",
    "student": "학생",
    "not_working": "무직",
}
_MARITAL_KO = {
    "single": "미혼", "married": "기혼", "divorced": "이혼", "bereaved": "사별",
}
_PREGNANCY_KO = {"pregnant": "임신 중", "postpartum": "산후", "none": "해당 없음"}
_HOUSEHOLD_KO = {
    "single_parent": "한부모", "multi_child": "다자녀", "multicultural": "다문화",
    "grandparent": "조손", "single_person": "1인 가구",
    "north_korean_defector": "북한이탈주민", "care_leaver": "자립준비청년",
    "facility_leaver": "시설퇴소", "newlywed": "신혼부부",
}
# veteran_status는 하드 게이트 슬롯이 아니라 known_veteran_status로 채워진
# interests 텍스트("국가유공자/보훈")로만 검색에 반영되므로(service.ask()
# docstring 참고), 이 슬롯 자체는 대화 중 채워지지 않는다. 그래도 프로필
# 표시용 라벨은 남겨둔다 - 다른 경로로 slots에 실릴 가능성까지 막지 않기
# 위함(예: 향후 회원 정보를 그대로 slots에 얹는 경로가 생길 경우).
_VETERAN_KO = {"registered": "보훈대상자", "not_registered": "해당 없음"}


def _build_profile(slots: Any) -> list[dict]:
    """N1이 파악한 슬롯을 ``[{"key","label","value"}...]``로 만든다.

    **생년월일 원문은 넣지 않는다.** N1이 파생한 만 나이만 싣는다
    (``docs/PII_LOGGING.md`` - 식별 가능한 원본 값은 응답에 담지 않는다).
    birth_date만 있고 age 파생이 실패한 경우에도 나이 항목을 생략한다 -
    "모른다"를 정직하게 비워 두는 편이 원본을 흘리는 것보다 낫다.
    """

    if not isinstance(slots, Mapping):
        return []

    items: list[dict] = []

    def add(key: str, label: str, value: object) -> None:
        if value:
            items.append({"key": key, "label": label, "value": str(value)})

    names = [str(x) for x in (slots.get("region_names") or []) if x]
    if names:
        if slots.get("region_scope") == "national" or names == ["전국"]:
            add("region", "지역", "전국 단위")
        else:
            add("region", "지역", ", ".join(names))

    age = slots.get("age")
    if isinstance(age, int):
        add("age", "나이", f"만 {age}세")

    for key, mapping, label in (
        ("gender", _GENDER_KO, "성별"),
        ("income_bracket", _INCOME_KO, "소득"),
        ("disability_status", _DISABILITY_KO, "장애"),
        ("employment_status", _EMPLOYMENT_KO, "취업 상태"),
        ("marital_status", _MARITAL_KO, "혼인"),
        ("pregnancy_status", _PREGNANCY_KO, "임신"),
        ("veteran_status", _VETERAN_KO, "보훈"),
    ):
        value = slots.get(key)
        if isinstance(value, str) and value != UNKNOWN and value in mapping:
            add(key, label, mapping[value])

    household = [
        _HOUSEHOLD_KO[x] for x in (slots.get("household_types") or []) if x in _HOUSEHOLD_KO
    ]
    if household:
        add("household_types", "가구 유형", ", ".join(household))

    if isinstance(slots.get("children_count"), int):
        add("children_count", "자녀 수", f"{slots['children_count']}명")
    if isinstance(slots.get("household_size"), int):
        add("household_size", "가구원 수", f"{slots['household_size']}명")

    interests = [str(x) for x in (slots.get("interests") or []) if x]
    if interests:
        add("interests", "관심 분야", ", ".join(interests))

    return items


def _build_summary(policies: list[PolicyView]) -> dict:
    """화면 상단 요약 카드 3개와 같은 수치.

    "미충족"과 "미확인"을 한 칸에 합치는 이유: 둘 다 *받을 수 있다고 말할 수
    없는* 상태이고, 미확인을 따로 작게 표시하면 사용자가 미충족만 보고
    "나머지는 되는구나"로 읽는다(docs/PROJECT_COMPLIANCE.md - 한계를 숨기지
    않는다).
    """

    statuses = [str(policy.get("eligibility_status") or "미확인") for policy in policies]
    return {
        "checked": len(policies),
        "eligible": statuses.count("충족"),
        "not_eligible_or_unknown": statuses.count("미충족") + statuses.count("미확인"),
    }


def _markdown_cell(value: object) -> str:
    """Markdown 표 셀을 깨뜨리는 구분자와 줄바꿈을 이스케이프한다.

    ``~``는 이스케이프가 아니라 ``-``로 바꾼다. GFM 취소선(``~~``)과 겹쳐서
    "중위소득 30~50%" 같은 범위 표기가 취소선으로 그려지기 때문이다.
    """

    if value is None:
        return "-"
    return (
        str(value)
        .replace("\\", "\\\\")
        .replace("|", "\\|")
        .replace("~", "-")
        .replace("\n", "<br>")
    )


def _build_output_markdown(policies: list[PolicyView]) -> str:
    """최종 정책 목록을 렌더링 가능한 Markdown 표로 만든다."""

    counts = _build_summary(policies)
    # 표만 있으면 "충족 0건"이라는 사실이 행을 하나하나 읽어야 보인다.
    # 화면 상단 요약 카드와 같은 수치를 한 줄로 먼저 적는다.
    summary_line = (
        f"**확인한 제도 {counts['checked']}건** · "
        f"자격 충족 {counts['eligible']}건 · "
        f"미충족·미확인 {counts['not_eligible_or_unknown']}건\n"
    )
    header = (
        "| 순위 | 정책명 | 자격 확인 | 지원금 | 중복수급 | 출처 |\n"
        "|---:|---|---|---|---|---|"
    )
    if not policies:
        return summary_line + "\n" + header + "\n| - | 확인된 정책 없음 | - | - | - | - |"

    rows: list[str] = []
    for policy in policies:
        source_url = (policy.get("detail") or {}).get("source_url")
        source = f"[원문]({source_url})" if source_url else "-"
        rows.append(
            "| "
            + " | ".join(
                _markdown_cell(value)
                for value in (
                    policy.get("rank"),
                    policy.get("title"),
                    policy.get("eligibility_status"),
                    policy.get("amount_label"),
                    policy.get("duplicate_status"),
                    source,
                )
            )
            + " |"
        )
    return summary_line + "\n" + header + "\n" + "\n".join(rows)


def _build_output_text(
    policies: list[PolicyView], final_answer: str | None = None
) -> str:
    """최종 답변과 정책 비교 결과를 일반 문자열로 만든다."""

    sections: list[str] = []
    if isinstance(final_answer, str) and final_answer.strip():
        sections.append(final_answer.strip())

    if policies:
        lines = ["정책 비교"]
        for policy in policies:
            detail = policy.get("detail") or {}
            source_url = detail.get("source_url") or "출처 없음"
            lines.append(
                f"[{policy.get('rank', '-')}] {policy.get('title') or policy.get('policy_id')}"
                f" | 자격: {policy.get('eligibility_status', '미확인')}"
                f" | 지원금: {policy.get('amount_label', '지원금액 확인 필요')}"
                f" | 중복수급: {policy.get('duplicate_status', '미확인')}"
                f" | 출처: {source_url}"
            )
        sections.append("\n".join(lines))
    elif not sections:
        sections.append("확인된 정책이 없습니다.")

    return "\n\n".join(sections)


def _to_chat_response(result: dict, *, session_id: str, store: Any) -> ChatResponse:
    if "__interrupt__" in result:
        interrupt_payload = result["__interrupt__"]
        # graph.invoke()는 리스트, graph.stream()은 튜플로 준다 - 둘 다 첫
        # 원소의 .value가 질문 문자열이다.
        question = interrupt_payload[0].value
        missing_slots = result.get("missing_slots", [])
        return {
            "status": "needs_input",
            "question": question,
            "session_id": session_id,
            "missing_slots": missing_slots,
            "output_json": {
                "status": "needs_input",
                "session_id": session_id,
                "question": question,
                "missing_slots": missing_slots,
                # 되묻는 중에도 "지금까지 파악한 정보"를 함께 준다.
                "profile": _build_profile(result.get("slots")),
            },
            "output_text": (
                f"추가 정보가 필요합니다.\n{question}\n"
                f"부족한 정보: {', '.join(missing_slots) or '없음'}"
            ),
            "output_markdown": (
                "| 상태 | 추가 질문 | 부족한 정보 |\n"
                "|---|---|---|\n"
                f"| 추가 정보 필요 | {_markdown_cell(question)} | "
                f"{_markdown_cell(', '.join(missing_slots))} |"
            ),
            "llm_status": _llm_status(),
            "timing": _timing_report(),
        }

    policies_raw = (result.get("assembled_result") or {}).get("policies", {})
    query_id = result.get("query_id", session_id)
    ranked = _rank_policies(policies_raw)
    policy_views = [
        _build_policy_view(
            policy_id, entry, store=store, query_id=query_id, rank=i + 1, is_top=(i == 0)
        )
        for i, (policy_id, entry) in enumerate(ranked)
    ]
    _attach_duplicate_conflicts(policy_views)

    citations = result.get("final_citations", [])
    # 화면(첨부 이미지)에 보이는 항목을 그대로 담는다:
    #   summary  -> 상단 요약 카드 3개(확인한 제도 / 자격 충족 / 미충족·미확인)
    #   profile  -> 사이드바 "파악한 정보"
    #   policies -> 정책 카드(배지·제목·자격 근거·중복수급·관련 법령·상세)
    #   evidence_count -> "근거 문서 확인 (N건)"
    output_json = {
        "status": "answered",
        "session_id": session_id,
        "answer_status": result.get("answer_status"),
        "final_answer": result.get("final_answer"),
        "summary": _build_summary(policy_views),
        "profile": _build_profile(result.get("slots")),
        "evidence_count": len(citations),
        "final_citations": citations,
        "policies": policy_views,
    }
    final_answer = result.get("final_answer")

    return {
        "status": "answered",
        "session_id": session_id,
        "answer_status": result.get("answer_status"),
        "final_answer": final_answer,
        "final_citations": citations,
        "policies": policy_views,
        "output_json": output_json,
        "output_text": _build_output_text(policy_views, final_answer),
        "output_markdown": _build_output_markdown(policy_views),
        "llm_status": _llm_status(),
        "timing": _timing_report(),
    }


_VETERAN_INTEREST_KEYWORD = "국가유공자/보훈"


def ask(
    user_input: str,
    session_id: str,
    *,
    top_k: int = 5,
    extra_interests: list[str] | None = None,
    known_region: str | None = None,
    known_gender: str | None = None,
    known_birth_date: str | None = None,
    known_disability_status: str | None = None,
    known_income_bracket: str | None = None,
    known_household_types: list[str] | None = None,
    known_veteran_status: str | None = None,
) -> ChatResponse:
    """새 대화를 시작한다(N1 진입점). Streamlit에서 사용자가 채팅창에 처음
    질문을 입력했을 때 호출한다.

    ``top_k``는 화면의 "정책 후보 수" 설정값이다. 기본값은 기존과 같은 5이고,
    그래프가 1~20 범위를 검증한다. 후속 답변에서는 첫 요청의 값이 LangGraph
    체크포인터에 보존되므로 다시 전달하지 않는다.

    ``extra_interests``는 화면에서 직접 고른 "지원조건"·"관심 분야"다. N1이
    발화에서 뽑은 interests와 **합집합**으로 누적돼 N4 검색 질의에 들어간다
    (slot_parser._MULTI_VALUE_FIELDS). 사용자가 말로 표현하지 못한 범주를
    체크박스로 보완하는 용도이고, 자격 판정에는 쓰이지 않는다 - interests는
    소프트 슬롯이라 하드 게이트/필터에 관여하지 않는다. 로그인 사용자는 이
    선택지의 기본값이 회원가입 때 저장한 관심조건으로 채워져 오는 게
    보통이지만(화면 쪽 책임), 그래도 값 자체는 매 요청 이 인자로 새로 받는다
    - 세션에서 고친 값이 회원 프로필을 되돌려 쓰지 않는다.

    ``known_region``은 로그인한 사용자가 회원가입 때 저장해 둔 거주 지역(시/도
    전체 명칭, 예: ``"서울특별시"``)이다. ``normalize_region_input()``으로
    N1과 같은 방식으로 정규화해 초기 슬롯에 미리 채운다 - 이미 아는 지역을
    대화로 또 묻지 않기 위함이다. **대화가 우선한다**: N1은 이번 턴 발화에
    지역처럼 보이는 말이 있으면 그 값으로 덮어쓰고, 없을 때만 이 초기값을
    그대로 둔다(``slot_parser.parse_slots`` 참고) - 로그인 사용자가 가족 등
    다른 지역을 언급해도 무시되지 않는다. 정규화에 실패하면(형식이 이상하거나
    빈 문자열) 조용히 건너뛰고 기존처럼 대화로 묻는다 - 잘못된 지역으로
    검색이 진행되는 것보다 한 번 더 묻는 편이 안전하다.

    ``known_gender``/``known_birth_date``도 같은 방식이다 - 회원가입 때
    저장한 성별("male"/"female")·생년월일(ISO ``YYYY-MM-DD``)을 초기 슬롯에
    미리 채워 N1이 다시 묻지 않게 한다. 둘 다 ``known_region``과 똑같이
    **대화가 우선**하고(``slot_parser.parse_slots``의 기존 병합 규칙을 그대로
    타므로 이 함수는 초기값만 얹는다), 계약에 없는 값이거나(``is_valid_slot_value``)
    파싱 불가능한 날짜면(``parse_birth_date``) 조용히 건너뛴다.

    ``known_disability_status``/``known_income_bracket``도 같은 방식이다 -
    회원가입 때 저장한 장애 등록 여부("registered"/"not_registered")·소득
    구간("under_30" 등)을 초기 슬롯에 미리 채운다. 둘 다 계약에 없는 값이면
    조용히 건너뛴다.

    ``known_household_types``는 회원가입 때 저장한 가구유형 목록(예:
    ``["single_parent", "newlywed"]``)이다. 소프트 슬롯(``household_types``)
    이라 하드 게이트에도 검색 필터에도 관여하지 않고, 계약에 있는 값만 골라
    초기 슬롯에 채운다.

    ``known_veteran_status``는 회원가입 때 저장한 보훈대상자 여부다. **하드/
    소프트 필터로 연결하지 않는다** - 정부24 raw 지원조건 sidecar
    (``policy_conditions.py``)의 JA 코드 중 어느 것이 보훈에 대응하는지
    검증할 방법이 없어서, 추측한 코드로 필터를 걸면 검증 안 된 조건으로
    정책이 조용히 잘못 걸러질 위험이 있다(``graph.slot_schema.VeteranStatus``
    클래스 docstring 참고 - "지어내지 않는다" 원칙). 대신 ``"registered"``면
    이미 안전하게 검증된 소프트 경로인 ``interests``에
    ``"국가유공자/보훈"``(``streamlit_ui.constants.INTEREST_OPTIONS``와 동일
    문자열)을 얹어 검색 질의만 넓힌다 - 자격 판정에는 관여하지 않는다.

    ``answer_followup()``에는 이 인자들이 없다. 재개 시점에는 이미 체크포인터에
    슬롯이 있고, 중간에 초기 슬롯을 갈아끼우면 이전 턴의 판정 근거와
    어긋나기 때문이다 - 화면에서 선택을 바꿨다면 새 상담으로 물어야 한다.
    """

    TIMER.reset()
    with ExitStack() as request_timer:
        request_timer.enter_context(TIMER.measure("request_total"))
        graph = get_graph()
        store = get_store()
        with _llm_request_scope():
            interests = [str(item) for item in (extra_interests or []) if item]
            initial_slots: dict = {}
            if interests:
                initial_slots["interests"] = interests
            if known_region:
                region_scope, region_names = normalize_region_input(known_region)
                if region_scope is not RegionScope.UNKNOWN:
                    initial_slots["region_scope"] = region_scope.value
                    initial_slots["region_names"] = region_names
            if known_gender and is_valid_slot_value("gender", known_gender):
                initial_slots["gender"] = known_gender
            if known_birth_date and parse_birth_date(known_birth_date, date.today()):
                initial_slots["birth_date"] = known_birth_date
            if known_disability_status and is_valid_slot_value(
                "disability_status", known_disability_status
            ):
                initial_slots["disability_status"] = known_disability_status
            if known_income_bracket and is_valid_slot_value(
                "income_bracket", known_income_bracket
            ):
                initial_slots["income_bracket"] = known_income_bracket
            if known_household_types:
                valid_household_types = {member.value for member in HouseholdType}
                household_types = [
                    str(item)
                    for item in known_household_types
                    if str(item) in valid_household_types
                ]
                if household_types:
                    initial_slots["household_types"] = household_types
            if known_veteran_status and is_valid_slot_value(
                "veteran_status", known_veteran_status
            ) and known_veteran_status == "registered":
                if _VETERAN_INTEREST_KEYWORD not in interests:
                    interests.append(_VETERAN_INTEREST_KEYWORD)
                initial_slots["interests"] = interests
            result = run_graph(
                graph,
                user_input=user_input,
                session_id=session_id,
                top_k=top_k,
                slots=initial_slots or None,
            )
            # llm_status는 request scope 안에서, timing은 측정 종료 뒤 읽는다.
            request_timer.close()
            return _to_chat_response(result, session_id=session_id, store=store)


def answer_followup(session_id: str, user_input: str) -> ChatResponse:
    """직전 ``ask()``(또는 ``answer_followup()``)가 ``status="needs_input"``을
    돌려준 세션을, 사용자의 답변으로 재개한다(N3 interrupt 재개). ``ask()``와
    같은 ``session_id``로만 호출할 수 있다 - 체크포인터에 해당 세션의 이전
    진행 상태가 없으면 LangGraph가 에러를 낸다."""

    TIMER.reset()
    with ExitStack() as request_timer:
        request_timer.enter_context(TIMER.measure("request_total"))
        graph = get_graph()
        store = get_store()
        with _llm_request_scope():
            result = resume_graph(graph, session_id=session_id, user_input=user_input)
            request_timer.close()
            return _to_chat_response(result, session_id=session_id, store=store)


__all__ = [
    "ask",
    "answer_followup",
    "connect_store",
    "build_embedding_provider",
    "build_llm_client",
    "get_graph",
    "get_store",
    "get_llm_client",
    "ChatResponse",
    "PolicyView",
    "PolicyDetail",
]
